# HabitFlow — Habit Tracker Android App

A gamified habit-tracking app built with **Kotlin + Jetpack Compose + Room**.

## Features included
- Add habits with custom emoji + color
- Daily check-off with animated habit cards
- Automatic streak tracking (current + longest)
- Weekly progress dots per habit
- XP & Level system — earn XP per completion, bonus XP every 7-day streak, level-up celebration popup
- Vibrant custom Material3 theme (violet/coral/mint), light & dark mode support
- Local persistence (Room database) — works fully offline

## How to run it

### Option A — Android Studio (desktop/laptop)
1. Install **Android Studio** (free): https://developer.android.com/studio
2. Open Android Studio → "Open" → select this `HabitFlow` folder
3. Let Gradle sync (first time will download dependencies — needs internet)
4. Click the green **Run** button with an emulator or a physical phone connected (enable USB debugging on your phone in Developer Options)
5. The app installs and launches automatically

### Option B — Gitpod (works from a phone browser, no laptop needed)
This project includes a `.gitpod.yml` that auto-installs the Android SDK when the workspace opens.

1. Push this project to a GitHub repo (e.g. `yourusername/habitflow`)
2. In your phone browser, go to `https://gitpod.io/#https://github.com/yourusername/habitflow`
3. Sign in with GitHub — Gitpod spins up a cloud Linux workspace and automatically runs the SDK setup (takes a few minutes the first time)
4. Once setup finishes, run in the terminal:
   ```
   ./gradlew assembleDebug
   ```
5. Find the built file at `app/build/outputs/apk/debug/app-debug.apk`, download it from Gitpod's file browser, and install it on your Android phone (allow "install unknown apps" for your browser when prompted)

## Project structure
```
app/src/main/java/com/habitflow/app/
  data/            → Room entities, DAO, database, repository, XP store
  ui/theme/        → Colors, typography, Material3 theme
  ui/components/   → Reusable UI: HabitCard, XpHeader
  ui/screens/      → HomeScreen, AddHabitScreen
  navigation/       → Navigation graph
  MainActivity.kt   → Entry point
```

## Ideas for next features (not yet built)
- Notifications/reminders for habits
- Cloud backup (Firebase) so data survives a reinstall
- Widgets for home screen
- Social/friend leaderboards
- Custom habit icons beyond the emoji set

---

## Publishing to the Google Play Store & monetizing

### 1. Before you publish
- **Test thoroughly** on a real device, different screen sizes if possible.
- Pick a unique `applicationId` in `app/build.gradle.kts` (currently `com.habitflow.app` — change this if you want your own package name, e.g. `com.yourname.habitflow`).
- Add a real app icon (currently using the default) — you can generate one via Android Studio: right-click `res` → New → Image Asset.
- Write a short **privacy policy** page (a simple hosted webpage works) — required by Google if you collect any data or show ads.

### 2. Create a signed release build
1. In Android Studio: **Build → Generate Signed Bundle / APK**
2. Choose **Android App Bundle (.aab)** — this is what Play Store wants now (not raw .apk)
3. Create a new keystore (a file that cryptographically signs your app) — **back this up somewhere safe**, you need the same one for every future update
4. Build the release `.aab` file

### 3. Google Play Console setup
1. Go to https://play.google.com/console
2. Pay the **one-time $25 USD registration fee** (no recurring cost)
3. Create a new app → fill in store listing (title, description, screenshots, feature graphic, privacy policy link)
4. Upload your `.aab` file under **Production → Create new release**
5. Fill out the required **Data Safety** and **Content rating** questionnaires
6. Submit for review (usually takes a few hours to a couple of days)

### 4. How to earn money from it
Common approaches, often combined:
- **Ads**: Integrate Google AdMob (banner/interstitial ads). Free to add, but changes user experience — best for a free app with light ads.
- **Freemium**: Keep the app free, offer a one-time "Pro" unlock (e.g. unlimited habits, custom themes, no ads) via **Google Play Billing**.
- **Subscription**: Recurring monthly/yearly fee for premium features (e.g. cloud sync, advanced stats) — also via Play Billing.
- **Paid app**: Charge upfront — harder to get downloads for a habit tracker since there's heavy free competition.

For a habit tracker specifically, the most common successful model is **free with ads + an optional ad-free/Pro one-time purchase**.

I haven't wired up ads or in-app purchases in this build — that requires setting up an AdMob account (or Play Billing) and adding your own account IDs, which I can help you add once you're ready to go down that path.
