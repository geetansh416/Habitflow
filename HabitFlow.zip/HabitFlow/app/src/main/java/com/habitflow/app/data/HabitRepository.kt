package com.habitflow.app.data

import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class HabitRepository(private val dao: HabitDao) {

    fun getActiveHabits(): Flow<List<Habit>> = dao.getActiveHabits()

    suspend fun addHabit(name: String, emoji: String, colorHex: Long, targetDaysPerWeek: Int) {
        dao.insertHabit(
            Habit(
                name = name,
                emoji = emoji,
                colorHex = colorHex,
                targetDaysPerWeek = targetDaysPerWeek,
                createdAtEpochDay = LocalDate.now().toEpochDay()
            )
        )
    }

    suspend fun archiveHabit(habitId: Long) = dao.archiveHabit(habitId)

    /** Toggle today's completion for a habit and recompute its streak. Returns XP earned (0 if un-completing). */
    suspend fun toggleToday(habit: Habit): Int {
        val today = LocalDate.now().toEpochDay()
        val existing = dao.getCompletion(habit.id, today)
        var xpEarned = 0

        if (existing != null) {
            dao.deleteCompletion(existing)
        } else {
            dao.insertCompletion(HabitCompletion(habit.id, today))
            xpEarned = XP_PER_COMPLETION
        }

        val allCompletions = dao.getCompletionsForHabit(habit.id).map { it.epochDay }.toSet()
        val newStreak = calculateCurrentStreak(allCompletions, today)
        val newLongest = maxOf(habit.longestStreak, newStreak)

        // Streak milestone bonus XP (every 7-day streak)
        if (existing == null && newStreak > 0 && newStreak % 7 == 0) {
            xpEarned += STREAK_MILESTONE_BONUS
        }

        dao.updateHabit(
            habit.copy(currentStreak = newStreak, longestStreak = newLongest)
        )

        return xpEarned
    }

    /** Walks backward from today counting consecutive completed days. */
    private fun calculateCurrentStreak(completedDays: Set<Long>, today: Long): Int {
        if (today !in completedDays) {
            // Streak is broken as of today unless yesterday was completed and today just hasn't happened yet.
            // For simplicity: streak only counts if today is completed.
            return 0
        }
        var streak = 0
        var day = today
        while (day in completedDays) {
            streak++
            day--
        }
        return streak
    }

    suspend fun getWeekCompletions(habitId: Long): List<Boolean> {
        val today = LocalDate.now().toEpochDay()
        val startOfWeek = today - 6
        val completions = dao.getCompletionsInRange(startOfWeek, today)
            .filter { it.habitId == habitId }
            .map { it.epochDay }
            .toSet()
        return (startOfWeek..today).map { it in completions }
    }

    companion object {
        const val XP_PER_COMPLETION = 10
        const val STREAK_MILESTONE_BONUS = 50
        const val XP_PER_LEVEL = 100

        fun levelForXp(totalXp: Int): Int = (totalXp / XP_PER_LEVEL) + 1
        fun xpIntoCurrentLevel(totalXp: Int): Int = totalXp % XP_PER_LEVEL
    }
}
