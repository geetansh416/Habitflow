package com.habitflow.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.habitflow.app.ui.screens.AddHabitScreen
import com.habitflow.app.ui.screens.HomeScreen
import com.habitflow.app.viewmodel.HabitViewModel

object Routes {
    const val HOME = "home"
    const val ADD_HABIT = "add_habit"
}

@Composable
fun HabitFlowNavGraph(viewModel: HabitViewModel) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onAddHabitClick = { navController.navigate(Routes.ADD_HABIT) }
            )
        }
        composable(Routes.ADD_HABIT) {
            AddHabitScreen(
                viewModel = viewModel,
                onDone = { navController.popBackStack() }
            )
        }
    }
}
