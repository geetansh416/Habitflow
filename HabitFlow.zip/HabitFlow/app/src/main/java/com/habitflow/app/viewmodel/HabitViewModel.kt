package com.habitflow.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.habitflow.app.data.Habit
import com.habitflow.app.data.HabitDatabase
import com.habitflow.app.data.HabitRepository
import com.habitflow.app.data.UserProgressStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class HabitUiState(
    val habits: List<Habit> = emptyList(),
    val totalXp: Int = 0,
    val level: Int = 1,
    val xpIntoLevel: Int = 0,
    val justLeveledUp: Boolean = false,
    val lastXpGain: Int = 0
)

class HabitViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: HabitRepository
    private val progressStore = UserProgressStore(application)

    private val _uiState = MutableStateFlow(HabitUiState())
    val uiState: StateFlow<HabitUiState> = _uiState.asStateFlow()

    init {
        val dao = HabitDatabase.getInstance(application).habitDao()
        repository = HabitRepository(dao)

        val startXp = progressStore.getTotalXp()
        _uiState.value = _uiState.value.copy(
            totalXp = startXp,
            level = HabitRepository.levelForXp(startXp),
            xpIntoLevel = HabitRepository.xpIntoCurrentLevel(startXp)
        )

        viewModelScope.launch {
            repository.getActiveHabits().collect { habits ->
                _uiState.value = _uiState.value.copy(habits = habits)
            }
        }
    }

    fun addHabit(name: String, emoji: String, colorHex: Long, targetDaysPerWeek: Int) {
        viewModelScope.launch {
            repository.addHabit(name, emoji, colorHex, targetDaysPerWeek)
        }
    }

    fun archiveHabit(habitId: Long) {
        viewModelScope.launch { repository.archiveHabit(habitId) }
    }

    fun toggleToday(habit: Habit) {
        viewModelScope.launch {
            val xpEarned = repository.toggleToday(habit)
            if (xpEarned > 0) {
                val previousLevel = HabitRepository.levelForXp(progressStore.getTotalXp())
                val newTotal = progressStore.addXp(xpEarned)
                val newLevel = HabitRepository.levelForXp(newTotal)
                _uiState.value = _uiState.value.copy(
                    totalXp = newTotal,
                    level = newLevel,
                    xpIntoLevel = HabitRepository.xpIntoCurrentLevel(newTotal),
                    justLeveledUp = newLevel > previousLevel,
                    lastXpGain = xpEarned
                )
            }
        }
    }

    suspend fun getWeekCompletions(habitId: Long): List<Boolean> =
        repository.getWeekCompletions(habitId)

    fun consumeLevelUpFlag() {
        _uiState.value = _uiState.value.copy(justLeveledUp = false)
    }
}
