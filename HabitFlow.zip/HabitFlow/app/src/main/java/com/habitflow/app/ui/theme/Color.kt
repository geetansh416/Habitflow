package com.habitflow.app.ui.theme

import androidx.compose.ui.graphics.Color

// Core brand palette — vibrant, energetic, not stock Material blue
val Color_White = Color(0xFFFFFFFF)
val VioletPrimary = Color(0xFF6C4FF5)
val VioletDark = Color(0xFF4B2FD0)
val CoralAccent = Color(0xFFFF6B6B)
val MintAccent = Color(0xFF2FE3B4)
val SunnyYellow = Color(0xFFFFC857)
val SkyBlue = Color(0xFF4FB4FF)

val BackgroundLight = Color(0xFFF8F7FC)
val SurfaceLight = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1D1B2E)
val TextSecondary = Color(0xFF6E6B85)

val BackgroundDark = Color(0xFF15131F)
val SurfaceDark = Color(0xFF211E30)
val TextPrimaryDark = Color(0xFFF2F1F7)
val TextSecondaryDark = Color(0xFFA8A5BD)

// Habit card color options — user picks one per habit
val HabitColorPalette = listOf(
    VioletPrimary,
    CoralAccent,
    MintAccent,
    SunnyYellow,
    SkyBlue,
    Color(0xFFFF8FB1), // pink
    Color(0xFF8C6BFF), // periwinkle
    Color(0xFF3DDC97)  // emerald
)
