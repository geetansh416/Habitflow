package com.habitflow.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class Habit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val emoji: String,           // e.g. "\uD83D\uDCAA", "\uD83D\uDCDA", "\uD83E\uDDD8"
    val colorHex: Long,          // packed ARGB color for the habit card
    val targetDaysPerWeek: Int = 7,
    val createdAtEpochDay: Long,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val isArchived: Boolean = false
)

@Entity(
    tableName = "completions",
    primaryKeys = ["habitId", "epochDay"]
)
data class HabitCompletion(
    val habitId: Long,
    val epochDay: Long   // LocalDate.toEpochDay() — one row per completed day
)
