package com.habitflow.app.data

import android.content.Context

class UserProgressStore(context: Context) {
    private val prefs = context.getSharedPreferences("habitflow_progress", Context.MODE_PRIVATE)

    fun getTotalXp(): Int = prefs.getInt(KEY_XP, 0)

    fun addXp(amount: Int): Int {
        val newTotal = getTotalXp() + amount
        prefs.edit().putInt(KEY_XP, newTotal).apply()
        return newTotal
    }

    companion object {
        private const val KEY_XP = "total_xp"
    }
}
