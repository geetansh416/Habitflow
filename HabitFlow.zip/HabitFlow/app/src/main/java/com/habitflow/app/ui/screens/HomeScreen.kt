package com.habitflow.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.habitflow.app.data.Habit
import com.habitflow.app.ui.components.HabitCard
import com.habitflow.app.ui.components.XpHeader
import com.habitflow.app.viewmodel.HabitViewModel
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HabitViewModel,
    onAddHabitClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val weekCache = remember { mutableStateMapOf<Long, List<Boolean>>() }
    val today = remember { LocalDate.now().toEpochDay() }

    LaunchedEffect(uiState.habits) {
        uiState.habits.forEach { habit ->
            weekCache[habit.id] = viewModel.getWeekCompletions(habit.id)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("HabitFlow", fontWeight = FontWeight.Bold) }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddHabitClick) {
                Icon(Icons.Filled.Add, contentDescription = "Add habit")
            }
        }
    ) { padding ->
        if (uiState.habits.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("\u2728", style = MaterialTheme.typography.headlineLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No habits yet — tap + to add your first one")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                item {
                    XpHeader(level = uiState.level, xpIntoLevel = uiState.xpIntoLevel)
                    Spacer(modifier = Modifier.height(4.dp))
                }
                items(uiState.habits, key = { it.id }) { habit: Habit ->
                    val week = weekCache[habit.id] ?: List(7) { false }
                    val isDoneToday = week.lastOrNull() ?: false
                    HabitCard(
                        habit = habit,
                        isDoneToday = isDoneToday,
                        weekProgress = week,
                        onToggle = {
                            viewModel.toggleToday(habit)
                        },
                        onLongPress = { viewModel.archiveHabit(habit.id) }
                    )
                }
                item { Spacer(modifier = Modifier.height(60.dp)) }
            }
        }

        if (uiState.justLeveledUp) {
            LevelUpBanner(
                level = uiState.level,
                onDismiss = { viewModel.consumeLevelUpFlag() }
            )
        }
    }
}

@Composable
private fun LevelUpBanner(level: Int, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Nice!") }
        },
        title = { Text("\uD83C\uDF89 Level Up!") },
        text = { Text("You've reached Level $level. Keep the streak going!") }
    )
}
