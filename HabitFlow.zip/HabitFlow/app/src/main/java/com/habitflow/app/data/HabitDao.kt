package com.habitflow.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitDao {

    @Query("SELECT * FROM habits WHERE isArchived = 0 ORDER BY createdAtEpochDay ASC")
    fun getActiveHabits(): Flow<List<Habit>>

    @Insert
    suspend fun insertHabit(habit: Habit): Long

    @Update
    suspend fun updateHabit(habit: Habit)

    @Query("UPDATE habits SET isArchived = 1 WHERE id = :habitId")
    suspend fun archiveHabit(habitId: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCompletion(completion: HabitCompletion)

    @Delete
    suspend fun deleteCompletion(completion: HabitCompletion)

    @Query("SELECT * FROM completions WHERE habitId = :habitId")
    suspend fun getCompletionsForHabit(habitId: Long): List<HabitCompletion>

    @Query("SELECT * FROM completions WHERE habitId = :habitId AND epochDay = :epochDay LIMIT 1")
    suspend fun getCompletion(habitId: Long, epochDay: Long): HabitCompletion?

    @Query("SELECT COUNT(*) FROM completions WHERE epochDay = :epochDay")
    fun getCompletionCountForDay(epochDay: Long): Flow<Int>

    @Query("SELECT * FROM completions WHERE epochDay BETWEEN :startDay AND :endDay")
    suspend fun getCompletionsInRange(startDay: Long, endDay: Long): List<HabitCompletion>
}
